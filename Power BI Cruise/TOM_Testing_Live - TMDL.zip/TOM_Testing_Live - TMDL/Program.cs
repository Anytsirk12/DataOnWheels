﻿using System;
using Microsoft.AnalysisServices.Tabular;
using Microsoft.AnalysisServices.Tabular.Tmdl;

namespace TOM_Testing_Live_TMDL
{
        internal class Program
        {
        static void Main(string[] args)
        {
//-------------- Connect to PBI Premium Workspace ---------------- //

            // create the connect string - powerbi://api.powerbi.com/v1.0/myorg/WORKSPACE_NAME
            string workspaceConnection = "powerbi://api.powerbi.com/v1.0/myorg/Happy%20Coding";
            string connectString = $"DataSource={workspaceConnection}";

            // connect to the Power BI workspace referenced in connect string
            Server server = new Server();
            server.Connect(connectString);


//---------------- Convert file to a TMDL format -------------------//
///*
        // enumerate through datasets in workspace to display their names
            foreach (Database database in server.Databases)
            {
                Console.WriteLine($"ID : {database.ID}, Name : {database.Name}, CompatibilityLevel: {database.CompatibilityLevel}, Last Updated : {database.LastSchemaUpdate}");
            }

            Model model = server.Databases["93992cd0-87e3-4915-b893-076556fa3fdc"].Model;

        //set the destination folder within the project folder         
        {
          var destinationFolder = $"C:\\Users\\krist\\Desktop\\TOM_Testing_Live - TMDL\\TMDL_scripts\\{model.Name}-tmdl";
          TmdlSerializer.SerializeModel(model.Model, destinationFolder);
        }

            Console.WriteLine($"Model deserialized into TMDL format");
//*/
//---------------- Push changes from TMDL to dataset -------------------//
/*
            var tmdlFolderPath = $"C:\\Users\\krist\\Desktop\\TOM_Testing_Live - TMDL\\TMDL_scripts\\Model-tmdl";
            //deserializing the model will put it back in the JSON format PBI service expects
            var tmdl_model = TmdlSerializer.DeserializeModel(tmdlFolderPath);
            {
                using (var remoteDatabase = server.Databases[tmdl_model.Database.ID])
                {
                    tmdl_model.CopyTo(remoteDatabase.Model);

                    remoteDatabase.Model.SaveChanges();
                }
            }

            model.RequestRefresh(RefreshType.Full);
            model.SaveChanges();
            Console.WriteLine($"Model updated from TMDL Script");
            Console.WriteLine($"Script Complete!");
//*/
   
        }
    }
}


