﻿using System;
using Microsoft.AnalysisServices.Tabular;
using Microsoft.AnalysisServices.Tabular.Tmdl;

namespace TOM_Testing_Live_TMDL
{
        internal class Program
        {
        static void Main(string[] args)
        {
//-------------- Connect to PBI Premium Workspace ---------------- //

            // create the connect string - powerbi://api.powerbi.com/v1.0/myorg/WORKSPACE_NAME
            string workspaceConnection = "powerbi://api.powerbi.com/v1.0/myorg/Happy%20Coding";
            string connectString = $"DataSource={workspaceConnection}";

            // connect to the Power BI workspace referenced in connect string
            Server server = new Server();
            server.Connect(connectString);
            Model model = server.Databases["93992cd0-87e3-4915-b893-076556fa3fdc"].Model;

            //---------------- Convert file to a TMDL format -------------------//
            /*
            // enumerate through datasets in workspace to display their names
            foreach (Database database in server.Databases)
            {
                Console.WriteLine($"ID : {database.ID}, Name : {database.Name}, CompatibilityLevel: {database.CompatibilityLevel}, Last Updated : {database.LastSchemaUpdate}");


                //set the destination folder within the project folder
                Model model = database.Model;
                var model_name = model.Database.Name;
                var destinationFolder = $"C:\\Users\\krist\\Desktop\\TOM_Testing_Live - TMDL\\TMDL_scripts\\{model_name}-tmdl";
                TmdlSerializer.SerializeModel(model.Model, destinationFolder);
                
            }
            Console.WriteLine($"Model deserialized into TMDL format");
//*/
            //---------------- Push changes from TMDL to dataset -------------------//
            /*
                        var tmdlFolderPath = $"C:\\Users\\krist\\Desktop\\TOM_Testing_Live - TMDL\\TMDL_scripts\\TOM & XMLA POC TMDL-tmdl";
                        //deserializing the model will put it back in the JSON format PBI service expects
                        var tmdl_model = TmdlSerializer.DeserializeModel(tmdlFolderPath);
                        {
                            using (var remoteDatabase = server.Databases[tmdl_model.Database.ID])
                            {
                                tmdl_model.CopyTo(remoteDatabase.Model); //Make sure DiscourageImplicitMeasures is set to true on your model to make calculation groups

                                remoteDatabase.Model.SaveChanges();
                            }
                        }

                        model.RequestRefresh(RefreshType.Full);
                        model.SaveChanges();
                        Console.WriteLine($"Model updated from TMDL Script");
                        Console.WriteLine($"Script Complete!");
            //*/



            //if you don't specify a database, it will only grab models from the first database in the list
            foreach (Table table in model.Tables)
            {
                Console.WriteLine($"Table : {table.Name} IsHidden? : {table.IsHidden}");
            }

            // Specify a single table in the dataset
            Table table_calc_group = model.Tables["OutToSea"];


            // List out the columns in the product table
            foreach (Column column in table_calc_group.Columns)
            {
                Console.WriteLine($"Columns: {column.Name}");
            }
        }
    }
}


